<?php

  session_start(); //spustíme session
  /** @var \PDO $db */
  require_once __DIR__.'/db.php'; //načteme připojení k databázi

  #region kontrola, jestli je přihlášený uživatel platný
  if (!empty($_SESSION['user_id'])){
    $userQuery=$db->prepare('SELECT user_id FROM n_users WHERE user_id=:id AND active=1 LIMIT 1;');
    $userQuery->execute([
                          ':id'=>$_SESSION['user_id']
                        ]);
    if ($userQuery->rowCount()!=1){
      //uživatel už není v DB, nebo není aktivní => musíme ho odhlásit
      unset($_SESSION['user_id']);
      unset($_SESSION['user_name']);
      header('Location: ./');
      exit();
    }
  }
  #endregion kontrola, jestli je přihlášený uživatel platný