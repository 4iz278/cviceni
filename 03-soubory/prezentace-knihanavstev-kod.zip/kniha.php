<?php

  $chyby=[];

  if (!empty($_POST) && !empty($_POST['akce']) && ($_POST['akce']=='komentar')){
    //kontroly vstupů
    $_POST['jmeno'] = empty($_POST['jmeno']) ? '' : trim($_POST['jmeno']);
    if (mb_strlen($_POST['jmeno'], 'utf-8') < 3){
      //chyba
      $chyby[]='Vyplňte jméno o délce alespoň 3 znaků.';
    }

    $_POST['email'] = empty($_POST['email']) ? '' : trim($_POST['email']);
    if (!empty($_POST['email'] && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))){
      $chyby[]='Zadejte platný mail, nebo nechte dané pole prázdné.';
    }

    //TODO další kontroly

    if (empty($chyby)){
      //sestavení obsahu příspěvku (v HTML)
      $obsah = '<b>'.htmlspecialchars($_POST['jmeno']).'</b><br />';
      $obsah.= nl2br( htmlspecialchars($_POST['text']) ).'<br /><br />'; //TODO obsah by mohl být hezčí, měl by tam být odkaz na mail atp.

      file_put_contents(__DIR__.'/obsah.html', $obsah, FILE_APPEND);

      //redirect
      header('Location: kniha.php');
      exit();
    }

  }

?><!DOCTYPE HTML>
<html lang="cs">
  <head>
    <meta charset="utf-8">
    <title>Kniha návštěv</title>
  </head>
  <body>
    <h1>Kniha návštěv</h1>

    <?php
      //načtení souboru s příspěvky
      include __DIR__.'/obsah.html';

      //zobrazení chyb
      if (!empty($chyby)){
        echo '<ul style="color:red;">';
        foreach ($chyby as $chyba){
          echo '<li>'.$chyba.'</li>';
        }
        echo '</ul>';
      }
    ?>

    <form method="post">
      <input type="hidden" name="akce" value="komentar" />

      <label for="jmeno">Jméno:</label><br />
      <input type="text" name="jmeno" id="jmeno" value="<?php echo htmlspecialchars($_POST['jmeno'] ?? ''); ?>" required /><br />

      <label for="email">E-mail:</label><br />
      <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" /><br />

      <label for="text">Komentář:</label><br />
      <textarea name="text" id="text" required ><?php echo htmlspecialchars($_POST['text'] ?? ''); ?></textarea><br />

      <button type="submit">Uložit</button>
    </form>

  </body>
</html>
